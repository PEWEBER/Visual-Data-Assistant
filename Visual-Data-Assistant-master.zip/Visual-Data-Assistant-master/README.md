# Visual-Data-Assistant	
Navigate to the Visual Data Assistant folder and launch the start node file for your operating system.
Navigate to Visual-Data-Assistant\KinectV2MouseControl-master\executables and launch the mouse control .exe( use default settings)
Navigate to the Visual Data Assistant folder and double click the localhost shortcut.